<?php
// Initialize the session
session_start();
?>
<!DOCTYPE html>
<!--suppress ALL -->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact Us</title>
    <!--Meta Tag-->
    <meta charset="UTF-8">
    <link rel="icon" href="images/favicon.png"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--Meta Tag End-->
    <!--Css Link-->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/magnific-popup.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
    <link href="css/responsive.css" rel="stylesheet" type="text/css">
    <!--Css Link End-->
    <!--Js Link-->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/counterup.min.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/magnific-popup.js"></script>
    <script src="js/custom.js"></script>
</head>
<body>
<!-- Navbar section-->
<nav class="navbar navbar-default bsl-navbar-custom navbar-fixed-top top-section">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-3 col-xs-12">
                <div class="navbar-header bsl-nav-logo">
                    <a href="index.php"><img src="images/logo.png" alt="logo" width="80"></a>
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mynavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
            </div>
            <div class="col-md-9 col-sm-9 col-xs-12">
                <div class="collapse navbar-collapse " id="mynavbar">
                    <ul class="nav navbar-nav text-left navbar-right nav-custom-ul">
                        <li><a href="index.php" class="bsl-menu">Home</a></li>
                        <li><a href="product/products.php">Products</a></li>
                        <li><a href="#reviews">Reviews</a></li>
                        <li><a href="#about us">About Us</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <li><?php
                            if(!isset($_SESSION['email']))

                            {
                                echo '<a href="user/login.php">Login</a>';
                            }
                            else
                            {
                                $username = $_SESSION['email'];
                                echo "<a href=user/welcome.php>$username</a>";
                            } ?>
                        </li>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav>

<section id="contact" class="bsl-footer-section">
    <div class="bsl-footer-bg" style="background-image: url(images/Image27.jpg)">
        <div class="container">
            <div class="bsl-footer-contain">
                <div class="bsl-adv-four-title text-center">
                    <h2>Contact Us</h2>
                    <div class="logoborder">
                        <span class="bsl-line-left"></span><img src="images/gym2.png" alt=""><span class="bsl-line-right"></span>
                    </div>
                </div>
                <form class="form-contactus margin-top-30 ">
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <div class="name">
                                <input type="text" placeholder="Name :" required="" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12">
                            <div class="email1 margin-top-30">
                                <input type="email" placeholder="Email :" required="" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 ">
                            <div class="phoneno1 margin-top-30">
                                <input type="text" placeholder="Phone:" required="" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12">
                            <div class="message margin-top-30">
                                <textarea placeholder="Message" rows="5" class="form-control"></textarea>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12">
                            <div class="sendmessage">
                                <button type="submit" class="btn margin-top-30">SEND MESSAGE</button>
                            </div>
                        </div>
                    </div>
                </form>
                <div class="bsl-footer-social text-center margin-top-30">
                    <div class="bsl-seperator-content">
                        <div class="bsl-seperator-line"></div>
                    </div>
                    <div class="bsl-footer-social-icon">
                        <a href=""><i class="active fa fa-facebook"></i></a>
                        <a href=""><i class="fa fa-twitter"></i></a>
                        <a href=""><i class="fa fa-instagram"></i></a>
                        <a href=""><i class="fa fa-snapchat-ghost"></i></a>
                    </div>
                    <div class="bsl-seperator-content">
                        <div class="bsl-seperator-line"></div>
                    </div>
                </div>
                <div class="bsl-footer-copyright text-center">
                    <p>BSL Pre-release by Andrei Rusu</p>
                </div>
            </div>
        </div>
    </div>
</section>
</body>
</html>