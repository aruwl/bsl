<?php
// Initialize the session
session_start();
$_SESSION['cart']=isset($_SESSION['cart']) ? $_SESSION['cart'] : array();
?>
<!DOCTYPE html>

<html>
    <head>
        <title>Body Supplement labs</title>
        <!--Meta Tag-->
        <meta charset="UTF-8">
        <link rel="icon" href="images/favicon.png"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!--Meta Tag End-->
        <!--Css Link-->
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="css/magnific-popup.css" rel="stylesheet" type="text/css">
        <link href="css/style.css" rel="stylesheet" type="text/css">
        <link href="css/responsive.css" rel="stylesheet" type="text/css">
        <!--Css Link End-->
        <!--Js Link-->
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/counterup.min.js"></script>
        <script src="js/waypoints.min.js"></script>
        <script src="js/magnific-popup.js"></script>
        <script src="js/custom.js"></script>
        <!--Js Link End-->
    </head>
    <body id="index" data-spy="scroll" data-target=".top-section">
        <!-- Navbar section-->
        <nav class="navbar navbar-default bsl-navbar-custom navbar-fixed-top top-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-3 col-xs-12">
                        <div class="navbar-header bsl-nav-logo">
                            <a href="index.php"><img src="images/logo.png" alt="logo" width="80"></a>
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mynavbar">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>
                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12">
                        <div class="collapse navbar-collapse " id="mynavbar">
                            <ul class="nav navbar-nav text-left navbar-right nav-custom-ul">
                                <li><a href="index.php" class="bsl-menu">Home</a></li>
                                <li><a href="product/products.php">Products</a></li>
                                <li><a href="#reviews">Reviews</a></li>
                                <li><a href="#about us">About Us</a></li>
                                <li><a href="contact.php">Contact</a></li>
                                <!--If logged in show email, otherwise "login"-->
                                <li><?php

                                    if(!isset($_SESSION['email']))

                                    {
                                        echo '<a href="user/login.php">Login</a>';
                                    }
                                    else
                                    {
                                        $username = $_SESSION['email'];
                                        echo "<a href=user/welcome.php>$username</a>";
                                    } ?>
                                </li>
                                <li <?php echo "Cart" ? "class='active'" : ""; ?> >
                                    <a href="product/cart.php">
                                        <?php
                                        // count products in cart
                                        $cart_count=count($_SESSION['cart']);
                                        ?>
                                        Cart <span class="badge" id="comparison-count"><?php echo $cart_count; ?></span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
        <!--banner section -->
        <section class="bsl-banner-section">
            <div class="bsl-banner-bg" style="background-image:url(images/Image1.jpg)">
                <div class="container">
                    <div class="bsl-banner-contain">
                        <div class="bsl-heading">
                            <h1>Now 25% Off selected items</h1>
                        </div>
                        <div class="bsl-bannersub-heading">
                            <p>High quality products for every kind of athlete at unbeatable prices</p>
                            <p>Free next day delivery on all orders over £49</p>
                            <p>Free samples on first order</p>
                        </div>  
                    </div>
                </div>
            </div>
        </section>
        <!--About section -->
        <section id="about" class="bsl-about-section padd-top-bottom-80">
            <div class="container">
                <div class="bsl-heading-title text-center">
                    <h2>Explore our Products</h2>
                    <div class="logoborder">
                        <span class="bsl-line-left"></span><img src="images/gym.png"><span class="bsl-line-right"></span>
                    </div>
                </div>
                <div class="row">
                    <div class="bsl-exploer-main contain bsl-clear">
                        <div class="col-md-4 col-sm-6">
                            <div class="bsl-sub-exploer-contain margin-top-30">
                                <div class="team">
                                    <figure class="team-img">
                                        <img src="images/Image2.png" class="img-responsive">
                                    </figure>
                                </div>
                                <h3>Weight Loss</h3>
                                <p>I must explain to you
                                    how all this mistaken idea
                                    of denouncing pleasure and praising pain was
                                    born and I will give you a
                                    complete account of the system,
                                    and expound the actual teachings
                                    of the great explorer of the truth</p>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="bsl-sub-exploer-contain margin-top-30">
                                <div class="team"> 
                                    <figure class="team-img">     
                                        <img src="images/Image3.png" class="img-responsive ">
                                    </figure>
                                </div>    
                                <h3>Body Building</h3>
                                <p>I must explain to you
                                    how all this mistaken idea 
                                    of denouncing pleasure and praising pain was 
                                    born and I will give you a 
                                    complete account of the system,
                                    and expound the actual teachings
                                    of the great explorer of the truth</p>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="bsl-sub-exploer-contain margin-top-30">
                                <div class="team">  
                                    <figure class="team-img">     
                                        <img src="images/Image4.png" class="img-responsive">
                                    </figure>
                                </div>    
                                <h3>Wellbeing</h3>
                                <p>I must explain to you
                                    how all this mistaken idea 
                                    of denouncing pleasure and praising pain was 
                                    born and I will give you a 
                                    complete account of the system,
                                    and expound the actual teachings
                                    of the great explorer of the truth</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section id="reviews" class="bsl-adv-section-four bsl-adv-section">
            <div class="bsl-adv-four-bg" style="background:url(images/Image18.png)">
                <div class="container">
                    <div class="bsl-adv-four-contain">
                        <div class="bsl-adv-four-title text-center">
                            <h2>Reviews</h2>
                            <div class="logoborder">
                                <span class="bsl-line-left"></span><img src="images/gym2.png"><span class="bsl-line-right"></span>
                            </div>
                        </div> 
                        <div id="myCarousel" class="carousel slide margin-top-30" data-ride="carousel">
                            <ol class="carousel-indicators">
                                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                                <li data-target="#myCarousel" data-slide-to="1"></li>
                                <li data-target="#myCarousel" data-slide-to="2"></li>
                            </ol>
                            <div class="carousel-inner">
                                <div class="item active">
                                    <div class="bsl-adv-four-icon">
                                        <i class="fa fa-quote-left" aria-hidden="true"></i>
                                    </div>
                                    <p>Doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo
                                        inventore veritatis et quasi architecto beatae vitae dicta sunt
                                        explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur
                                        aut odit aut fugit, sed quia
                                        consequuntur magni dolores eos qui ratione voluptatem
                                        sequi nesciunt. Neque porro quisquam est, qui dolorem</p>
                                    <img src="images/Image19.png" class="img-circle">
                                    <h4>Aldo Ferri</h4>
                                </div>
                                <div class="item">
                                    <div class="bsl-adv-four-icon">
                                        <i class="fa fa-quote-left" aria-hidden="true"></i>
                                    </div>
                                    <p>Doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo
                                        inventore veritatis et quasi architecto beatae vitae dicta sunt
                                        explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur
                                        aut odit aut fugit, sed quia
                                        consequuntur magni dolores eos qui ratione voluptatem
                                        sequi nesciunt. Neque porro quisquam est, qui dolorem</p>
                                    <img src="images/Image19.png" class="img-circle">
                                    <h4>Aldo Ferri</h4>
                                </div>
                                <div class="item">
                                    <div class="bsl-adv-four-icon">
                                        <i class="fa fa-quote-left" aria-hidden="true"></i>
                                    </div>
                                    <p>Doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo
                                        inventore veritatis et quasi architecto beatae vitae dicta sunt
                                        explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur
                                        aut odit aut fugit, sed quia
                                        consequuntur magni dolores eos qui ratione voluptatem 
                                        sequi nesciunt. Neque porro quisquam est, qui dolorem</p>
                                    <img src="images/Image19.png" class="img-circle">
                                    <h4>Aldo Ferri</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <script type="text/javascript">
            jQuery(document).ready(function ($) {
                $('.counter').counterUp({
                    delay: 20,
                    time: 1000
                });
            });
        </script>
        <!--End Counter Script-->
        <?php
        include "layout/layout_footer.php";
        ?>
    </body>
</html>
