
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

<!-- Latest compiled and minified Bootstrap JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<script>
    $(document).ready(function(){
        // add to cart button listener
        $('.add-to-cart-form').on('submit', function(){

            // info is in the table / single product layout
            var id = $(this).find('.product-id').text();
            var quantity = $(this).find('.cart-quantity').val();

            // redirect to add_to_cart.php, with parameter values to process the request
            window.location.href = "add_to_cart.php?id=" + id + "&quantity=" + quantity;
            return false;
        });

        // change product image on hover
        $(document).on('mouseenter', '.product-img-thumb', function(){
            var data_img_id = $(this).attr('data-img-id');
            $('.product-img').hide();
            $('#product-img-'+data_img_id).show();
        });

        // update quantity button listener
        $('.update-quantity-form').on('submit', function(){

            // get basic information for updating the cart
            var id = $(this).find('.product-id').text();
            var quantity = $(this).find('.cart-quantity').val();

            // redirect to update_quantity.php, with parameter values to process the request
            window.location.href = "update_quantity.php?id=" + id + "&quantity=" + quantity;
            return false;
        });
    });
</script>

<!--Footer Section-->
<section id="contact" class="bsl-footer-section">
    <div class="bsl-footer-bg" style="background-image: url(images/Image27.jpg)">
        <div class="container">
            <div class="bsl-footer-contain">
                <div class="bsl-footer-social text-center margin-top-30">
                    <div class="bsl-seperator-content">
                        <div class="bsl-seperator-line"></div>
                    </div>
                    <div class="bsl-footer-social-icon">
                        <a href=""><i class="active fa fa-facebook"></i></a>
                        <a href=""><i class="fa fa-twitter"></i></a>
                        <a href=""><i class="fa fa-instagram"></i></a>
                        <a href=""><i class="fa fa-snapchat-ghost"></i></a>
                    </div>
                    <div class="bsl-seperator-content">
                        <div class="bsl-seperator-line"></div>
                    </div>
                </div>
                <div class="bsl-footer-copyright text-center">
                    <p>Body Supplement Labs</p>
                </div>
            </div>
        </div>
    </div>
</section>

<a id="back-to-top" class="scrollTop bsl-back-to-top" href="" style="display: none">
    <img src="images/Up-Arrow.png" class="bsl-bounce" alt="top-arrow">
</a>