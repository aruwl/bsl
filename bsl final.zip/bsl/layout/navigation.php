<!-- navbar -->
<div class="navbar navbar-default navbar-static-top" role="navigation">
    <!-- Navbar section-->
    <nav class="navbar navbar-default bsl-navbar-custom navbar-fixed-top top-section">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-3 col-xs-12">
                    <div class="navbar-header bsl-nav-logo">
                        <a href="../index.php"><img src="../product/images/logo.png" alt="logo" width="80"></a>
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mynavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>
                </div>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <div class="collapse navbar-collapse " id="mynavbar">
                        <ul class="nav navbar-nav text-left navbar-right nav-custom-ul">
                            <li><a href="../index.php" class="bsl-menu">Home</a></li>
                            <li><a href="../product/products.php">Products</a></li>
                            <li><a href="#reviews">Reviews</a></li>
                            <li><a href="#about us">About Us</a></li>
                            <li><a href="../contact.php">Contact</a></li>
                            <!--If logged in show email, otherwise "login"-->
                            <li><?php

                                if(!isset($_SESSION['email']))

                                {
                                    echo '<a href="../user/login.php">Login</a>';
                                }
                                else
                                {
                                    $username = $_SESSION['email'];
                                    echo "<a href=user/welcome.php>$username</a>";
                                } ?>
                            </li>
                            <li <?php echo "Cart" ? "class='active'" : ""; ?> >
                                <a href="../product/cart.php">
                                    <?php
                                    // count products in cart
                                    $cart_count=count($_SESSION['cart']);
                                    ?>
                                    Cart <span class="badge" id="comparison-count"><?php echo $cart_count; ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>
</div>

<!-- /navbar -->