<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
  header("location: welcome.php");
  exit;
}
 
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$username = $password = "";
$username_err = $password_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if email is empty
    if(empty(trim($_POST["email"]))){
        $username_err = "Please enter email.";
    } else{
        $username = trim($_POST["email"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        $sql = "SELECT id, email, password FROM user WHERE email = ?";

        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = $username;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                // Check if email exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password);
                    if(mysqli_stmt_fetch($stmt)){
                        if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["email"] = $username;
                            
                            // Redirect user to welcome page
                            header("location: welcome.php");
                        } else{
                            // Display an error message if password is not valid
                            $password_err = "The password you entered was not valid.";
                        }
                    }
                } else{
                    // Display an error message if email doesn't exist
                    $username_err = "No account found with that email.";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
        
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <!--Meta Tag-->
    <meta charset="UTF-8">
    <link rel="icon" href="../images/favicon.png"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--Meta Tag End-->
    <!--Css Link-->
    <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="../css/magnific-popup.css" rel="stylesheet" type="text/css">
    <link href="../css/style.css" rel="stylesheet" type="text/css">
    <link href="../css/responsive.css" rel="stylesheet" type="text/css">
    <!--Css Link End-->
    <!--Js Link-->
    <script src="../js/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/counterup.min.js"></script>
    <script src="../js/waypoints.min.js"></script>
    <script src="../js/magnific-popup.js"></script>
    <script src="../js/custom.js"></script>
</head>
<body>
    <!-- Navbar section-->
    <nav class="navbar navbar-default bsl-navbar-custom navbar-fixed-top top-section">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-3 col-xs-12">
                    <div class="navbar-header bsl-nav-logo">
                        <a href="../index.php"><img src="../images/logo.png" alt="logo" width="80"></a>
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mynavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>
                </div>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <div class="collapse navbar-collapse " id="mynavbar">
                        <ul class="nav navbar-nav text-left navbar-right nav-custom-ul">
                            <li><a href="../index.php" class="bsl-menu">Home</a></li>
                            <li><a href="../product/products.php">Products</a></li>
                            <li><a href="#reviews">Reviews</a></li>
                            <li><a href="#about us">About Us</a></li>
                            <li><a href="../contact.php">Contact</a></li>
                            <li><a href="#login/register">Login/Register</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <section id="contact" class="bsl-footer-section">
        <div class="bsl-footer-bg" style="background-image: url(../images/Image27.jpg)">
            <div class="container">
                <div class="bsl-footer-contain">
                    <div class="bsl-adv-four-title text-center">
                        <h2>Login</h2>
                        <div class="logoborder">
                            <span class="bsl-line-left"></span><img src="../images/gym2.png" alt=""><span class="bsl-line-right"></span>
                        </div>
                    </div>
                    <p>Please fill in your credentials to login.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-login <?php echo (!empty($username_err)) ? 'has-error' : ''; ?>">
                            <label>Email</label>
                            <input type="text" name="email" class="form-control" value="<?php echo $username; ?>">
                            <span class="help-block"><?php echo $username_err; ?></span>
                        </div>
                        <div class="form-login <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
                            <label>Password</label>
                            <input type="password" name="password" class="form-control">
                            <span class="help-block"><?php echo $password_err; ?></span>
                        </div>
                        <div class="col-md-12 col-sm-12">
                            <div class="loginregister">
                                <button type="submit" class="btn margin-top-30">Login</button>
                            </div>
                        <p>Don't have an account? <a href="register.php">Sign up now</a>.</p>
                    </form>
                    <div class="bsl-footer-social text-center margin-top-30">
                        <div class="bsl-seperator-content">
                            <div class="bsl-seperator-line"></div>
                        </div>
                        <div class="bsl-footer-social-icon">
                            <a href=""><i class="active fa fa-facebook"></i></a>
                            <a href=""><i class="fa fa-twitter"></i></a>
                            <a href=""><i class="fa fa-instagram"></i></a>
                            <a href=""><i class="fa fa-snapchat-ghost"></i></a>
                        </div>
                        <div class="bsl-seperator-content">
                            <div class="bsl-seperator-line"></div>
                        </div>
                    </div>
                    <div class="bsl-footer-copyright text-center">
                        <p>BSL Pre-release by Andrei Rusu</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>
</html>