<?php
// Initialize the session
session_start();

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <title>Body Supplement labs</title>
    <!--Meta Tag-->
    <meta charset="UTF-8">
    <link rel="icon" href="../images/favicon.png"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--Meta Tag End-->
    <!--Css Link-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; text-align: center; }
    </style>
    <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="../css/magnific-popup.css" rel="stylesheet" type="text/css">
    <link href="../css/style.css" rel="stylesheet" type="text/css">
    <link href="../css/responsive.css" rel="stylesheet" type="text/css">
    <!--Css Link End-->
    <!--Js Link-->
    <script src="../js/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/counterup.min.js"></script>
    <script src="../js/waypoints.min.js"></script>
    <script src="../js/magnific-popup.js"></script>
    <script src="../js/custom.js"></script>
    <!--Js Link End-->
</head>
<body>
<nav class="navbar navbar-default bsl-navbar-custom navbar-fixed-top top-section">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-3 col-xs-12">
                <div class="navbar-header bsl-nav-logo">
                    <a href="../index.php"><img src="../images/logo.png" alt="logo" width="80"></a>
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mynavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
            </div>
            <div class="col-md-9 col-sm-9 col-xs-12">
                <div class="collapse navbar-collapse " id="mynavbar">
                    <ul class="nav navbar-nav text-left navbar-right nav-custom-ul">
                        <li><a href="../index.php" class="bsl-menu">Home</a></li>
                        <li><a href="../product/products.php">Products</a></li>
                        <li><a href="#reviews">Reviews</a></li>
                        <li><a href="#about us">About Us</a></li>
                        <li><a href="../contact.php">Contact</a></li>
                        <li><?php

                            if(!isset($_SESSION['email']))

                            {
                                echo '<a href="login.php">Login</a>';
                            }
                            else
                            {
                                $username = $_SESSION['email'];
                                echo "<a href=welcome.php>$username</a>";
                            } ?>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav>
<section id="welcome" class="bsl-our-gallery-section padd-top-bottom-80">
    <div class="page-header">
        <h1>Add a Payment Method</h1>
    </div>
    <form action="/action_page.php">

        <div class="row">
            <div class="col-50">
                <h3>Billing Address</h3>
                <label for="fname"><i class="fa fa-user"></i> Full Name</label>
                <input type="text" id="fname" name="firstname" placeholder="John M. Doe">
                <label for="email"><i class="fa fa-envelope"></i> Email</label>
                <input type="text" id="email" name="email" placeholder="john@example.com">
                <label for="adr"><i class="fa fa-address-card-o"></i> Address</label>
                <input type="text" id="adr" name="address" placeholder="542 W. 15th Street">
                <label for="city"><i class="fa fa-institution"></i> City</label>
                <input type="text" id="city" name="city" placeholder="New York">

                <div class="row">
                    <div class="col-50">
                        <label for="state">State</label>
                        <input type="text" id="state" name="state" placeholder="NY">
                    </div>
                    <div class="col-50">
                        <label for="zip">Zip</label>
                        <input type="text" id="zip" name="zip" placeholder="10001">
                    </div>
                </div>
            </div>

            <div class="col-50">
                <h3>Payment</h3>
                <label for="fname">Accepted Cards</label>
                <div class="icon-container">
                    <i class="fa fa-cc-visa" style="color:navy;"></i>
                    <i class="fa fa-cc-amex" style="color:blue;"></i>
                    <i class="fa fa-cc-mastercard" style="color:red;"></i>
                    <i class="fa fa-cc-discover" style="color:orange;"></i>
                </div>
                <label for="cname">Name on Card</label>
                <input type="text" id="cname" name="cardname" placeholder="John More Doe">
                <label for="ccnum">Credit card number</label>
                <input type="text" id="ccnum" name="cardnumber" placeholder="1111-2222-3333-4444">
                <label for="expmonth">Exp Month</label>
                <input type="text" id="expmonth" name="expmonth" placeholder="September">

                <div class="row">
                    <div class="col-50">
                        <label for="expyear">Exp Year</label>
                        <input type="text" id="expyear" name="expyear" placeholder="2018">
                    </div>
                    <div class="col-50">
                        <label for="cvv">CVV</label>
                        <input type="text" id="cvv" name="cvv" placeholder="352">
                    </div>
                </div>
            </div>

        </div>
        <label>
            <input type="checkbox" checked="checked" name="sameadr"> Shipping address same as billing
        </label>
        <input type="submit" value="Continue to checkout" class="btn">
    </form>
</section>
<!--Footer Section-->
<section id="contact" class="bsl-footer-section">
    <div class="bsl-footer-bg" style="background-image: url(../images/Image27.jpg)">
        <div class="container">
            <div class="bsl-footer-contain">
                <div class="bsl-footer-social text-center margin-top-30">
                    <div class="bsl-seperator-content">
                        <div class="bsl-seperator-line"></div>
                    </div>
                    <div class="bsl-footer-social-icon">
                        <a href=""><i class="active fa fa-facebook"></i></a>
                        <a href=""><i class="fa fa-twitter"></i></a>
                        <a href=""><i class="fa fa-instagram"></i></a>
                        <a href=""><i class="fa fa-snapchat-ghost"></i></a>
                    </div>
                    <div class="bsl-seperator-content">
                        <div class="bsl-seperator-line"></div>
                    </div>
                </div>
                <div class="bsl-footer-copyright text-center">
                    <p>BSL Pre-release by Andrei Rusu</p>
                </div>
            </div>
        </div>
    </div>
</section>

<a id="back-to-top" class="scrollTop bsl-back-to-top" href="" style="display: none">
    <img src="../images/Up-Arrow.png" class="bsl-bounce" alt="top-arrow">
</a>
</body>
</html>