<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
 
<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <title>Body Supplement labs</title>
    <!--Meta Tag-->
    <meta charset="UTF-8">
    <link rel="icon" href="../images/favicon.png"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--Meta Tag End-->
    <!--Css Link-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; text-align: center; }
    </style>
    <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="../css/magnific-popup.css" rel="stylesheet" type="text/css">
    <link href="../css/style.css" rel="stylesheet" type="text/css">
    <link href="../css/responsive.css" rel="stylesheet" type="text/css">
    <!--Css Link End-->
    <!--Js Link-->
    <script src="../js/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/counterup.min.js"></script>
    <script src="../js/waypoints.min.js"></script>
    <script src="../js/magnific-popup.js"></script>
    <script src="../js/custom.js"></script>
    <!--Js Link End-->
</head>
<body>
<section id="welcome" class="bsl-our-gallery-section padd-top-bottom-80">
    <div class="page-header">
        <h1>Hello <b><?php echo htmlspecialchars($_SESSION["email"]); ?></b>, Welcome to Body Suppliment Labs.</h1>
    </div>
    <p>
        <a href="reset-password.php" class="btn btn-warning">Reset Your Password</a>
        <a href="logout.php" class="btn btn-danger">Sign Out</a>
    </p>
</section>

    <nav class="navbar navbar-default bsl-navbar-custom navbar-fixed-top top-section">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-3 col-xs-12">
                    <div class="navbar-header bsl-nav-logo">
                        <a href="../index.php"><img src="../images/logo.png" alt="logo" width="80"></a>
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mynavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>
                </div>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <div class="collapse navbar-collapse " id="mynavbar">
                        <ul class="nav navbar-nav text-left navbar-right nav-custom-ul">
                            <li><a href="../index.php" class="bsl-menu">Home</a></li>
                            <li><a href="../product/products.php">Products</a></li>
                            <li><a href="#reviews">Reviews</a></li>
                            <li><a href="#about us">About Us</a></li>
                            <li><a href="../contact.php">Contact</a></li>
                            <li><?php

                                if(!isset($_SESSION['email']))

                                {
                                    echo '<a href="login.php">Login</a>';
                                }
                                else
                                {
                                    $username = $_SESSION['email'];
                                    echo "<a href=welcome.php>$username</a>";
                                } ?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>
<!--Footer Section-->
<section id="contact" class="bsl-footer-section">
    <div class="bsl-footer-bg" style="background-image: url(../images/Image27.jpg)">
        <div class="container">
            <div class="bsl-footer-contain">
                <div class="bsl-footer-social text-center margin-top-30">
                    <div class="bsl-seperator-content">
                        <div class="bsl-seperator-line"></div>
                    </div>
                    <div class="bsl-footer-social-icon">
                        <a href=""><i class="active fa fa-facebook"></i></a>
                        <a href=""><i class="fa fa-twitter"></i></a>
                        <a href=""><i class="fa fa-instagram"></i></a>
                        <a href=""><i class="fa fa-snapchat-ghost"></i></a>
                    </div>
                    <div class="bsl-seperator-content">
                        <div class="bsl-seperator-line"></div>
                    </div>
                </div>
                <div class="bsl-footer-copyright text-center">
                    <p>BSL Pre-release by Andrei Rusu</p>
                </div>
            </div>
        </div>
    </div>
</section>

<a id="back-to-top" class="scrollTop bsl-back-to-top" href="" style="display: none">
    <img src="../images/Up-Arrow.png" class="bsl-bounce" alt="top-arrow">
</a>
</body>
</html>