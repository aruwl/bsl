-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 21, 2019 at 10:25 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bsl_project_beta`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE `bank` (
  `card_number` bigint(16) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `balance` float(11,2) DEFAULT NULL,
  `date_expire` datetime DEFAULT NULL,
  `cvc` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'Gym Equipment'),
(2, 'Sport Nutrition'),
(3, 'General Health'),
(4, 'Food'),
(5, 'Protein');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `id` int(11) NOT NULL,
  `date_created` timestamp NULL DEFAULT NULL,
  `user_bank_card_number` int(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `order_id` int(11) NOT NULL,
  `id_product` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `total` float(11,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `price` float(11,2) DEFAULT NULL,
  `img_dir` varchar(255) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `img_dir`, `stock`, `category_id`, `created`) VALUES
(1, 'Diet Whey Protein Powder 1kg', 'PhD Diet Whey delivers a multitude of benefits. Not only does Diet Whey deliver 36g of quality protein per serving, but the protein derives from multiple sources giving you a variety of proteins that release into the blood stream at different stages which offer that drip feed effect of amino acids.\r\n\r\nFurthermore, as Diet Whey only contains 6g carbs per super serving and less than 200 calories, it is really macro-friendly & could fit into anybody\'s nutrition plan; whether you\'re carb cycling, following a ketogenic (keto) diet or just looking for something tasty that\'s low in calories, Diet Whey is the perfect option.\r\n\r\nIf this wasn\'t enough, Diet Whey also delivers Flaxseed, CLA, L-Carnitine and Green Tea Extract which all support fat loss.', 12.99, 'images/products/diet_whey_protein_powder.png', 50, 5, '0000-00-00 00:00:00'),
(2, 'PhD Smart Protein', 'Smart Protein is a new deliciously versatile protein powder that can be used in all sorts of ways; You can bake with it, include it in indulgent, home-made desserts, whip it into a tasty macro-friendly mousse or simply drink it.', 20.99, 'images/products/phd_smart_protein.png', 12, 5, '0000-00-00 00:00:00'),
(3, 'Synergy ISO-7 All In One Protein', 'Synergy ISO-7 is a lean, all in one, post workout shake.\r\n\r\nSynergy ISO-7 has been proven to be very popular with individuals and athletes after spells of intense physical activity that want to recover optimally & maintain a lean physique.', 34.99, 'images/products/synergy_iso-7_all_in_one_protein.png', 35, 5, '0000-00-00 00:00:00'),
(4, 'Reflex Vegan Protein', 'Get the fuel you need to grow and maintain muscle mass without the dairy, this vegan supplement is made with pea protein instead, plus it\'s free from artificial sweeteners and sugars. Available in 2.1kg tubs.', 31.99, 'images/products/reflex_vegan_protein.png', 44, 5, '0000-00-00 00:00:00'),
(5, 'Complete Pump Pre-Workout', 'Complete Pump Pre-Workout, is a stim-free, pump-based pre-workout supplement. It is a supercharged and highly-dosed formula, featuring over 22g active ingredients to help you get the most out of your training sessions. Unlike traditional pre-workouts which typically contain high doses of caffeine with moderate doses of ergogenic ingredients, Complete Pump Pre-Workout focusses purely around synergistic pump and performance-based ingredients.', 24.99, 'images/products/complete_pump_pre-workout.png', 8, 2, '0000-00-00 00:00:00'),
(6, 'Vitargo', 'Vitargo is the ultimate sports performance carbohydrate, delivering rapid glycogen supplies to the muscles (70% faster than other carbohydrates such as Dextrose and Maltodextrin).\r\n\r\nVitargo consists of much larger carbohydrate molecules than other sugar-based carbohydrates such as Dextrose, Fructose, Sucrose and Maltodextrin; which are often the preserve of the mainstream sports drinks you find in various gyms and supermarkets. These larger molecules ultimately enable Vitargo to move through the stomach 80% faster than the aforementioned products. The result of this is that Vitargo is absorbed extremely quickly and provides almost instant energy. Furthermore, when Vitargo is consumed after training or competition, it replenishes muscle glycogen levels 70% faster than other sports drinks. What\'s more, Vitargo is also 100% sugar-free!', 5.99, 'images/products/vitagro.png', 22, 2, '0000-00-00 00:00:00'),
(7, 'CISSUS QUADRANGULARIS CAPSULES', 'Cissus Quadrangularis has been used in Indian medicine for centuries Cissus Quadrangularis is sourced from the same region and is only produced in very small batches to guarantee quality and potency. In fact, our Cissus is so fresh that it\'s possible to be at your door less than 30 days after the Cissus Quadrangularis was harvested in India.\r\n\r\nCissus Quadrangularis Capsules 800mg suitable for anyone looking for an alternative to Glucosamine and Chondroitin type products. ', 23.99, 'images/products/cissus_quadrangularis_capsules.png', 3, 2, '0000-00-00 00:00:00'),
(8, 'LEUCINE TABLETS', 'Leucine Tablets contain a full 1000mg of leucine per tablet i.e. the 1000mg refers to the active ingredient, not the tablet size. This means you do not need to take 8-10 tablets to get an appropriate amount of leucine; 2-4 tablets provides you with 2-4g of leucine.\r\n\r\nLeucine itself is an essential amino acid (EAA); this means that the body cannot produce it and, as such, it needs to be obtained from the diet. Leucine is also the key branched chain amino acid (BCAA).\r\n\r\nLeucine Tablets 1000mg provide a potent dose of 1000mg per tablet and are suitable for those looking to increase dietary Leucine intake. ', 9.99, 'images/products/leucine_tablets.png', 15, 2, '0000-00-00 00:00:00'),
(9, 'Omega 3 Fish Oil Softgels', 'Omega 3 Fish Oil Softgels contains 180mg EPA and 120mg DHA per softgel this is far higher than many fish oil products. If you\'re looking for even higher levels of EPA and DHA, then take a look at our popular Super Strength Fish Oils 1000mg.  Omega 3 Fish Oil Softgels deliver EPA and DHA in a cost effective format.\r\n\r\nOmega 3 is derived from Fish Oil and has a number of benefits including contributing to normal function of the heart at a dosage of 250mg EPA and DHA per day. Vitamin E has also been added to prevent damage to the fish oil.\r\n\r\nOmega 3 Fish Oil Softgels 1000mg are a potent source of EPA and DHA, which contributes to normal function of the heart. ', 3.49, 'images/products/omega_3_fish_oil_softgels.png', 11, 3, '0000-00-00 00:00:00'),
(10, 'Organic Virgin Coconut Oil', 'Nutritionally speaking, Organic Virgin Coconut Oil impresses in many regards. It is cholesterol-free and contains zero trans-fatty acids, yet it is packed with medium chain triglycerides (MCTs), particularly lauric acid. Organic Virgin Coconut Oil actually contains more lauric acid than any other food source in fact, Lauric acid comprises in excess of 50% of the fat content within Organic Virgin Coconut Oil.\r\n\r\nMade from the flesh of the coconut, Organic Virgin Coconut Oil makes an ideal replacement for other oils and oil based products such as vegetable oil, olive oil and butter/margarine. Simply use it as you would these other products and benefit from its fantastic nutritional profile and great taste.', 7.50, 'images/products/organic_virgin_coconut_oil.png', 48, 3, '0000-00-00 00:00:00'),
(11, 'Active WMN', 'As you\'d expect, ACTIVE WMN contains all the vitamins and micro nutrients that active women need on a daily basis. But we have gone one step further. We only use the premium sources of these active ingredients, so you can be confident in the quality and bio availability of each ingredient.', 14.99, 'images/products/active_wmn.png', 15, 3, '0000-00-00 00:00:00'),
(12, 'Vitamin d3 Tablets', 'Vitamin D is a fat soluble vitamin that contributes to muscle function, normal bones, immune function as well as playing a role in cell division.\r\n\r\nVitamin D3, also referred to as Cholecalciferol, can be consumed in the diet, although it\'s present in relatively few foods. Oily fish alongside fortified dairy and cereal products are the most common sources of Vitamin D.\r\n\r\nExposure to sunlight is responsible for Vitamin D synthesis, and is responsible for the majority of Vitamin D intake in the body. ', 3.99, 'images/products/vitamin_d3_tablets.png', 25, 3, '0000-00-00 00:00:00'),
(13, 'Chocolate Whey Balls', 'Chocolate Whey Balls are an exciting snack with a twist! Chocolate Whey Balls match the taste of leading confectionary products, but provide an impressive 20g protein per 100g. Chocolate Whey Balls have a crunchy whey protein centre and are coated in delicious milk, dark or white chocolate. If you\'re looking for a tasty treat that is also high in protein, then look no further!\r\n\r\nChocolate Whey Balls are suitable for anyone looking for a tasty treat that is also high in protein. They are ideal for cheat days, or just for when you can\'t resist that chocolate craving, so why not satisfy it and increase your protein intake at the same time!', 7.29, 'images/products/chocolate_whey_balls.png', 67, 4, '0000-00-00 00:00:00'),
(14, 'High Protein Cookies', 'The ultimate high-protein treat. This protein-packed snack is a tasty way to help grow and maintain important muscles, whatever your fitness goals. Plus, each cookie has 20g of carbs, helping to fuel your workouts, or even just your day.', 11.99, 'images/products/high_protein_cookies.png', 33, 4, '0000-00-00 00:00:00'),
(15, 'Liquid Egg Whites', 'Liquid Egg Whites provide a convenient alternative to the laborious task of separating egg whites. Liquid Egg Whites contain only 1% carbohydrate and 0.5% fat - meaning they are virtually pure protein goodness!\r\n\r\nLiquid Egg Whites are perfect for anyone who wants to increase their protein consumption to help the growth and maintenance of muscle mass. Anyone who cooks and bakes should also have a stash of these in their kitchen cupboard.', 1.49, 'images/products/liquid_egg_whites.png', 28, 4, '0000-00-00 00:00:00'),
(16, 'Chia Seeds', 'Chia Seeds popularity has grown rapidly over the last few years and for good reason. These tiny black and white seeds come with many benefits, and pack a huge punch in relation to their size. Chia Seeds make an ideal snack for between meals, or can be added to meals and shakes to boost nutritional content.\r\n\r\nChia Seeds are sourced from South America and have a mild, yet slightly nutty taste. They are of the highest quality guaranteed, with an outstanding nutritional profile. They contain high levels of protein (20g per 100g), are an excellent source of fibre (38g per 100g) as well as omega fatty acids and minerals.\r\n\r\nWhen Chia Seeds are mixed with water, the liquid takes on a gooey appearance. This is due to Chia\'s ability to draw in water, making it a perfect addition to an intra-workout drink, keeping you fully hydrated throughout your workout.', 2.99, 'images/products/chia_seeds.png', 41, 4, '0000-00-00 00:00:00'),
(17, 'Body power 5kg Hex Cast Iron Dumbbell', 'Our BodyPower cast iron dumbbells are made to an incredibly high standard, with all products undergoing strict quality control. The casting quality, surface treatment and weight tolerance must meet a set standard of quality.', 12.99, 'images/products/body_power_5kg_hex_cast_iron_dumbbell.png', 13, 1, '0000-00-00 00:00:00'),
(18, 'York 6kg Vinyl Kettlebell', 'York Fitness Vinyl Kettlebells are the ultimate fitness partner, helping develop functional strength, power, endurance, core stability and balance - the total workout tool. \r\n\r\nAs the York Fitness Vinyl Kettlebells can be swung, lifted and pushed, they offer users a comprehensive full body, fat burning workout like no other kind of fitness equipment can.\r\n\r\nAt the bottom of each York Fitness Vinyl Kettlebell are four stability feet that prevent the Kettlebell from slipping or toppling over. \r\n\r\nErgonomically designed handles make the York Fitness Vinyl Kettlebells comfortable to hold, whilst providing a firm grip so you can get the most out of each exercise. ', 11.00, 'images/products/york_6kg_vinyl_kettlebell.png', 4, 1, '0000-00-00 00:00:00'),
(19, 'Body Power Solid Standard Curl Bar', 'A proven favourite of bodybuilders everywhere, this bar isolates and intensifies development of the Bicep and Forearm muscles. Specifically angled to eliminate stress on the wrists and elbows. Solid Steel Smooth Bar 47 inches long 11 Lbs', 14.99, 'images/products/body_power_solid_standard_curl_bar.png', 2, 1, '0000-00-00 00:00:00'),
(20, 'Body Power Standard Tri Grip Discs 1.25Kg (x2)', 'The Bodypower Tri-Grip standard weight plates have an easy grip tri-grip design that allow for a quick change over when adjusting weights, the plates will fit onto any standard bar, machine or attatchment. The plates are of a high, durable quality suitable for commercial and home gym use. \r\n\r\nOur BodyPower cast iron plates are made to an incredibly high standard, with all products undergoing strict quality control. The casting quality, surface treatment and weight tolerance must meet a set standard of quality. Some of the cheaper alternatives that are available on the web are inferior products, which are not constructed to this same standard.', 5.00, 'images/products/body_power_standard_tri_grip_discs.png', 18, 1, '0000-00-00 00:00:00'),
(21, 'Carb Crusher Selection Box', 'All three delicious flavours in one super-convenient box.\r\n\r\nCarb Crusher bars are the ultimate high-protein snack with their triple layers and topped with crunchy crispies they\'re a super-nutritious treat for sweet-tooth snackers everywhere.\r\n\r\nSo, indulge in a world of bittersweet Dark Chocolate Sea Salt, fruity Strawberry Cheesecake, and smooth Caramel Nut with our Carb Crusher Selection Box you\'re guaranteed to find your favourite.', 4.49, 'images/products/carb_crusher_selection_box.png', 84, 4, '0000-00-00 00:00:00'),
(22, 'BCAA Drink', 'Zero-carb BCAA drink, refreshing pre-workout.\r\n\r\nQuench your thirst with BCAA Drink, packed with amino acids, B vitamins and caffeine to provide that perfect pick me up, anytime of the day. Plus, it\'s zero sugar, contains no carbs, and comes in refreshingly fruity flavours.\r\n\r\nBCAAs naturally occur in protein which helps to build and repair new muscle, important whatever your fitness ambitions. Plus, our fruity drink is packed with 180mg of caffeine, helping to increase performance and keep you sharp.', 1.89, 'images/products/bcaa_drink.png', 6, 4, '0000-00-00 00:00:00'),
(23, 'Impact Whey Protein', 'Premium whey packed with 21g of protein per serving, for the everyday protein you need from a quality source with all-natural nutritionals, it\'s ideal for all of your fitness goals.\r\n\r\nIt\'s convenient, high-quality protein that helps grow and maintain important muscle and with just 1.9g of fat, 1g of carbs, and only 103 calories per serving, it\'s here to support all your fitness goals.', 6.79, 'images/products/impact_whey_protein.png', 63, 5, '0000-00-00 00:00:00'),
(24, 'Weight Gainer Blend', 'This beast of a supplement boasts 31g of protein, a staggering 50g of carbs, and a massive total of 388 calories per serving, setting you up to achieve those all-important gains all while boosting your recovery2 after those high-intensity workouts.\r\n\r\nPacked with a blend of high-quality, fast and slow digesting proteins, that helps grow and maintain important muscle. This won\'t just spike your protein uptake, but help to maintain it throughout the day.\r\n\r\nThere\'s also an energising carb boost from oat flour and maltodextrin, helping you to recover after exercise and provide the fuel for your next session.', 27.19, 'images/products/weight_gainer_blend.png', 18, 5, '0000-00-00 00:00:00'),
(25, 'Pea Protein Isolate', 'Completely free from soy and dairy, our all-natural Pea Protein Isolate is packed with 23g protein per serving, perfect for those training on a plant-based diet.\r\n\r\nCreated from only plant-based sources, it\'s a convenient way to get quality protein into your diet  helping you grow and maintain important muscles, which is vital for progress whether you\'re looking to gain size, tone-up or lose weight.', 12.99, 'images/products/pea_protein_isolate.png', 101, 5, '0000-00-00 00:00:00'),
(26, 'Collagen Protein', 'This blend is made with highly purified collagen peptides to give you a delicious shake with at least 90% protein content, helping you to meet your daily intake without taking on unnecessary fats and carbs ideal for weight loss and muscle gaining goals.\r\n\r\nThere\'s 22g of protein per serving, which helps to grow and maintain muscle, making this an important training support to help you progress with fitness goals.', 16.99, 'images/products/collagen_protein.png', 5, 5, '0000-00-00 00:00:00'),
(27, 'Alpha Men Multivitamin Tablets', 'Our ultra formula of essential vitamins and minerals including calcium, vitamin D, selenium, vitamin B5, biotin, as well as energising natural extracts boosting your everyday wellbeing while training hard, and dealing with the stresses and strains of a busy lifestyle.\r\n\r\nWith a whole range of essential vitamins and minerals, including vitamin B and selenium, it\'s the perfect daily supplement for the active man, with calcium and biotin helping to keep your mind alert and vitamin B5 reducing everyday tiredness.', 14.99, 'images/products/alpha_men_multivitamin_tablets.png', 42, 3, '0000-00-00 00:00:00'),
(28, 'Hemp Oil Capsules', 'Derived from the seeds of the Cannabis sativa plant, our hemp oil has been cold-pressed to ensure its natural qualities are retained when being transformed into our easy-to-take soft gel capsules. Alongside an array of other phytochemicals, the oil also includes the highly sought after omega 3, 6 & 9 fatty acids. Omega 3 & 6 polyunsaturated fats are deemed essential given that our body cannot create them and therefore they must be obtained through the diet.  ', 12.79, 'images/products/hemp_oil_capsules.png', 34, 3, '0000-00-00 00:00:00'),
(29, 'Healthshield Antioxidant Formula', 'Despite our best intentions, many of us struggle to eat a healthy, balanced diet which can result in an inadequate supply of essential vitamins and minerals in addition to other beneficial nutrients.  \r\n\r\nTo help fill in some nutritional gaps, our team of experts have crafted this formula to provide a number of heavily researched polyphenols, flavonoids and carotenoids as well as three antioxidant vitamins for comprehensive and synergistic health support. \r\n\r\nOne of the key nutrients within this supplement is resveratrol, a flavonoid well-known for its presence in red wine. This phytochemical is renowned for its ability to help the normal workings of the cardiovascular system. The carotenoid lycopene is another heavily researched nutrient within HealthShield Antioxidant Formula and is often associated with tomatoes, given that we typically get most of our lycopene through tomato consumption.  \r\n\r\nAs well as numerous other specialist compounds such as alpha lipoic acid, quercetin and astaxanthin, each serving is rich in riboflavin, vitamin C and vitamin E, which all help to protect the body from oxidative stress. Widely known as vitamin B2, riboflavin also contributes to the maintenance of normal vision. The aforementioned health claims have been authorised by the European Food Safety Authority (EFSA).  ', 22.69, 'images/products/healthshield_antoxidant_formula.png', 32, 3, '0000-00-00 00:00:00'),
(30, 'Super Magnesium With Vitamin B Complex', 'Magnesium is the second most abundant mineral in the body, and is responsible for healthy muscle function and contraction. It is also essential for the maintenance of healthy bones and teeth. Magnesium can be found in foods like almonds, broccoli, coffee and dairy products, but is also popularly taken in supplement form to ensure sufficient daily requirements are met. Magnesium deficiencies may weaken bones, muscles and teeth, which can increase the risk of suffering more serious damage. ', 9.29, 'images/products/super_magnesium_with_vitamin_b_complex.png', 84, 3, '0000-00-00 00:00:00'),
(31, 'Probiotic Max Tablets', 'Probiotic Max is a uniquely formulated supplement designed to help support and promote the presence of friendly gut bacteria. The human digestive system is designed to naturally balance levels of good and bad bacteria to maintain good health. Good bacteria assist in the breakdown of foods and the absorption of nutrients, whilst also defending against the damage caused by bad bacteria. If the level of bad bacteria becomes overwhelming, the body can begin to suffer. Simply Supplements have created this supplement to help support and replenish the good bacteria in your body, by providing over a billion of these in every single serving.', 42.09, 'images/products/probiotic_max_tablets.png', 18, 3, '0000-00-00 00:00:00'),
(32, 'Chewable Vitamin C Tablets', 'No artificial colours, flavours or preservatives.\r\nSuitable for vegetarians and vegans.\r\n\r\nVitamin C is an antioxidant that contributes to the protection of cells from oxidative stress.\r\nIt helps maintain a healthy immune system, the body\'s natural defence mechanism, and also helps maintain healthy skin.\r\nGetting an adequate, regular intake in your diet is essential as this vitamin is not stored in the body.', 3.59, 'images/products/chewable_vitamin_c_tablets.png', 73, 3, '0000-00-00 00:00:00'),
(33, 'SlimFast Shake Powder', 'High protein\r\nSource of fibre\r\nJust add skimmed milk\r\n23 vitamins & minerals\r\nNo added sugar - contains naturally occurring sugars\r\nScientifically proven plan* effective weight loss\r\n*Substituting two daily meals of an energy restricted diet with meal replacements contributes to weight loss.', 7.25, 'images/products/slimfast_shake_powder.png', 42, 4, '0000-00-00 00:00:00'),
(34, 'Battery+/_3 Powder', 'Battery+/_3 is designed to facilitate the window of opportunity that may exist in and around the workout period.\r\n\r\nThe formula contains a precision blend of three key carbohydrate sources, all designed to assist the strength and endurance athlete. L-Glutamine and BCAAs, align the product perfectly for use before, during or after intense exercise with potassium to support healthy muscle function, as well as magnesium, which helps reduce tiredness and fatigue and contributes to normal energy yielding metabolism.', 15.99, 'images/products/battery_3_powder.png', 68, 2, '0000-00-00 00:00:00'),
(35, 'Intra BCAA+', 'Intra BCAA+ is a unique and innovative branched chain amino acid drink formulated with Instantised BCAAs, CocoMineral Coconut Water Extract, Hydrolysed Whey Isolate, L-Glutamine and Vitamin C.\r\n\r\nIntra BCAA+ is ideal for men and women who require a refreshing BCAA and electrolyte drink to help prevent muscle breakdown during exercise.\r\n\r\nIntra BCAA+ is suitable for vegetarians and is tailor made to be used during your workout to help you achieve your body goals.\r\n\r\n', 22.00, 'images/products/intra_bcaa+.png', 1, 2, '0000-00-00 00:00:00'),
(36, 'Waxy Vol Powder', 'Waxy Vol can be used by athletes from all sports, seeking a pure carbohydrate powder that is low in fat and sugar. It can also be added to your PhD protein shake to create a balanced protein to carbohydrate ratio.\r\n\r\n', 14.99, 'images/products/waxy_vol_powder.png', 18, 2, '0000-00-00 00:00:00'),
(37, 'VMX2 Powder', 'VMX2, ultra-concentrated, super-strength matrix of performance boosting ingredients, represents the ultimate evolution in pre-workout nutrition. VMX2 is so concentrated, we have even left all colouring out, in order to fit in the necessary active ingredients to ensure an even greater pre-workout experience. This advanced, high-powered formula contains only serious ingredients such as Beta Alanine, Peptide bonded L-Arginine, the Nitrate-rich Beta Vulgaris, the patented Creatine Monohydrate Creapure and a full strength Vitamin B matrix, to provide you with the catalyst to increase your training intensity, strength and delay fatigue and tiredness.\r\n\r\nVMX2 contains just 1.2g of carbohydrates per serving and less than 0.5g of added dextrose, to ensure it is suitable for athletes on a low carbohydrate diet seeking only the leanest of muscle gains. Prime your muscles for growth realisation by using VMX2 before every intense exercise session.', 19.99, 'images/products/vmx2_powder.png', 13, 2, '0000-00-00 00:00:00'),
(38, 'Amino Drive', 'Formulated for the performance-driven (but also great for those who just want to stay focussed and give their best regardless of whether they are smashing out bench press PB\'s or not), Amino Drive contains all 9 essential amino acids, has only 59 calories per serving and tastes great.', 13.99, 'images/products/amino_drive.png', 6, 2, '0000-00-00 00:00:00'),
(39, 'VMX2 Shot', 'VMX2 Shot is an ultra powerful pre-workout formulation, in a convenient shot format. Containing beta alanine, arginine, citrulline malate and Sustamine, as well as vitamins B6 and B12 to help reduce tiredness and fatigue, VMX2 Shot is the ideal formula to help maximize your training.\r\n\r\nVMX2 Shot is sugar free and suitable for athletes on a low carbohydrate diet seeking only the leanest of muscle gains', 1.99, 'images/products/vmx2_shot.png', 28, 2, '0000-00-00 00:00:00'),
(40, 'Amino Support Tablets', 'There are two types of amino acids: essential and nonessential. Essential amino acids cannot be synthesized by the body so must be obtained from our diet. Nutrition Amino Support contains 8 essential amino acids, including the 3 BCAAs, which are often used as part of an athlete\'s training and nutritional plan. Alongside these important amino acids, PhD have also included vitamin B6, which provides a variety of health benefits.\r\n\r\nAmino Support can help to maintain a healthy nervous system and immune system, help to reduce tiredness and fatigue, as well as supporting protein and glycogen metabolism.', 14.99, 'images/products/amino_support_tablets.png', 46, 3, '0000-00-00 00:00:00'),
(41, 'Pre-Workout BURN', 'PhD Pre-Wkt BURN is a high energy pre-workout drink to be consumed before any serious fat burning exercise or high intensity training. Delivering fully dosed levels of all major ingredients, Pre-Wkt BURN most importantly delivers the correct amount of the research driven and hugely impactful TeaCrine (1,3,7,9-Tetramethyluric acid).\r\n\r\nAlong with the naturally sourced TeaCrine, it also delivers a combined 6g dose of L-Glutamine/Branched Chain Amino acids, vital for the user who wishes to train upon waking on an empty stomach and needs to protect against muscle loss. Completing Pre-Wkt BURN is 225mg of caffeine per serving, L-Carnitine, L-Tyrosine and CLA. Pre-Wkt BURN is designed for men and women embarking on high intensity fat burning workouts such as H.I.I.T, intense weight training, metabolic circuit training and intense cardio', 18.99, 'images/products/pre-workout_burn.png', 41, 2, '0000-00-00 00:00:00'),
(42, 'Pre-Workout Perform', 'PhD Pre-Wkt PERFORM is a high-intensity pre-workout drink to be used before serious performance training of any kind. It is specifically targeted for use by athletes seeking increased strength, power, and performance in bursts of short-term, high-intensity exercise.\r\n\r\nContaining optimal and fully dosed levels of Creatine Monohydrate and Beta Alanine, Pre-Wkt PERFORM also contains 2.6g per serving of the revolutionary whole food Peak 02, a brand new adaptogenic whole food linked through research with having a beneficial impact on improving peak power output during workouts, click here for more detail on the power of Peak O2 and the history of adaptogens:\r\n\r\n', 18.99, 'images/products/pre-workout_perform.png', 61, 2, '0000-00-00 00:00:00'),
(43, 'Pre-Workout Pump', 'PhD Pre-Wkt PUMP contains the latest breakthrough ingredient technology for bodybuilders seeking serious muscle pumps leading to muscle growth activation. Containing over 2g of Arginine and Betaine per serving Pre-Wkt PUMP also contains the super-ingredient L-Norvaline. It also contains NO CAFFEINE.', 18.99, 'images/products/pre-workout_pump.png', 32, 2, '0000-00-00 00:00:00'),
(44, 'L-Leucine Capsules', 'L-Leucine is one of the key branched chain amino acids and has long been used by sporting professionals as part of their nutritional plans. As an essential amino acid, L-Leucine cannot be produced by the body and therefore must be obtained from the diet.\r\n\r\nAs one of the vital Branched Chain amino acids, Leucine is hugely important to support heavy training and the muscle building process. Excellent to stack with Pharma Whey HT+ and any high protein shake, L-Leucine can also be used pre workout with VMX2, during workout to boost the L-Leucine content of Intra BCAA+, or post workout with Recovery 2:. Many PhD users will use L-Leucine before bed to facilitate the period of re-building during sleep.', 6.49, 'images/products/l-leucine_capsules.png', 80, 3, '0000-00-00 00:00:00'),
(45, 'Reinforce Capsules', 'Ensuring that your bones and cartilage stay healthy is extremely important for anyone embarking on a serious training regime. PhD Nutrition Reinforce - joint health supplement contains glucosamine, chondroitin and hyaluronic acid, along with Vitamin C and MSM to supplement an intense training plan and active lifestyle.', 9.89, 'images/products/reinforce_capsules.png', 32, 3, '0000-00-00 00:00:00'),
(46, 'CLA Softgels', 'CLA (Conjugated Linoleic Acid) is derived from safflower oil. It is a naturally occurring fatty acid that cannot be produced by the body. CLA is found in foods such as milk, cheese & beef, but only in very small quantities. PhD CLA capsules are a simple way to achieve your CLA intake.\r\n\r\nCLA is an extremely popular product for dieters and over 30 clinical studies have been published investigating the effect of CLA on weight management.', 5.99, 'images/products/cla_softgels.png', 71, 3, '0000-00-00 00:00:00'),
(47, 'Protein Flapjack+', 'Protein Flapjack+ is an ideal snack for any athlete looking to increase muscle mass and help replenish the body with quality, healthy calories after a hard bout of intense exercise or throughout the day to support an athletic lifestyle. Providing 19 grams of protein and featuring the versatile benefits of premium quality whey protein and milk protein isolate.\r\n\r\nProtein Flapjack+ utilises finest rolled and malted oats for a sustained release of complex carbohydrates to help your body cope with the rigours of the athletic lifestyle and a serious training routine and contains less than 3g saturated fat, rather than the high fat content of regular flapjacks that are traditionally coated with margarine, vegetable oil and butter.\r\n', 2.00, 'images/products/protein_flapjack.png', 42, 4, '0000-00-00 00:00:00'),
(48, 'Yoga Mat', 'The yoga mats are lightweight and portable allowing users to take their mats wherever they go.\r\n\r\nThe cushioning system gives users support and also makes for a more comfortable yoga workout.', 12.99, 'images/products/yoga_mat.png', 11, 1, '0000-00-00 00:00:00'),
(49, 'GymGear Slam Ball', 'Perfect for explosive, powerful movements, our slam balls are manufactured from ultra durable materials to withstand anything you throw them at.\r\n\r\nThey provide an effective and fun way to build explosive strength, improve muscular endurance, increase speed and reaction time as well as strengthen and tone a wide variety of muscles.\r\n\r\nUnlike medicine balls, our slam balls boast a robust design that protects them against splitting, letting you take your training to the max in total confidence!\r\n\r\nIdeal for circuit training and functional / CrossFit style workouts, no gym or fitness studio is complete without this awesome training tool.', 14.40, 'images/products/gymgear_slam_ball.png', 19, 1, '0000-00-00 00:00:00'),
(50, 'Speed Ladder', 'Speed Ladder for intense training drills of the upper and lower body as well as excellent body stability.\r\n\r\nImprove acceleration, lateral quickness and change of direction. Gain greater body control by improving agility. Adapt training to sport specific movements to improve muscle memory', 30.49, 'images/products/speed_ladder.png', 12, 1, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` varchar(512) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`id`, `product_id`, `name`, `created`) VALUES
(1, 1, 'images/products/diet_whey_protein_powder.png', '2019-04-21 18:50:18'),
(2, 2, 'images/products/phd_smart_protein.png\r\n', '2019-04-21 18:50:28'),
(3, 3, 'images/products/synergy_iso-7_all_in_one_protein.png\r\n', '2019-04-21 18:50:35'),
(4, 4, 'images/products/reflex_vegan_protein.png\r\n', '2019-04-21 18:50:42'),
(5, 5, 'images/products/complete_pump_pre-workout.png\r\n', '2019-04-21 18:50:50'),
(6, 6, 'images/products/vitargo.png\r\n', '2019-04-21 18:50:58'),
(7, 7, 'images/products/cissus_quadrangularis_capsules.png\r\n', '2019-04-21 18:51:05'),
(8, 8, 'images/products/leucine_tablets.png\r\n', '2019-04-21 18:51:11'),
(9, 9, 'images/products/omega_3_fish_oil_softgels.png\r\n', '2019-04-21 18:51:20'),
(10, 10, 'images/products/organic_virgin_coconut_oil.png\r\n', '2019-04-21 18:51:30'),
(11, 11, 'images/products/active_wmn.png\r\n', '2019-04-21 18:51:37'),
(12, 12, 'images/products/vitamin_d3_tablets.png\r\n', '2019-04-21 18:51:44'),
(13, 13, 'images/products/chocolate_whey_balls.png\r\n', '2019-04-21 18:51:50'),
(14, 14, 'images/products/high_protein_cookies.png\r\n', '2019-04-21 18:51:59'),
(15, 15, 'images/products/liquid_egg_whites.png\r\n', '2019-04-21 18:52:09'),
(16, 16, 'images/products/chia_seeds.png\r\n', '2019-04-21 18:52:20'),
(17, 17, 'images/products/body_power_5kg_hex_cast_iron_dumbbell.png\r\n', '2019-04-21 18:52:45'),
(18, 18, 'images/products/york_6kg_vinyl_kettlebell.png\r\n', '2019-04-21 18:52:53'),
(19, 19, 'images/products/body_power_solid_standard_curl_bar.png\r\n', '2019-04-21 18:53:00'),
(20, 20, 'images/products/body_power_standard_tri_grip_discs.png\r\n', '2019-04-21 18:53:08'),
(21, 21, 'images/products/carb_crusher_selection_box.png\r\n', '2019-04-21 18:53:16'),
(22, 22, 'images/products/bcaa_drink.png\r\n', '2019-04-21 18:53:22'),
(23, 23, 'images/products/impact_whey_protein.png\r\n', '2019-04-21 18:53:28'),
(24, 24, 'images/products/weight_gainer_blend.png\r\n', '2019-04-21 18:53:35'),
(25, 25, 'images/products/pea_protein_isolate.png\r\n', '2019-04-21 18:53:45'),
(26, 26, 'images/products/collagen_protein.png\r\n', '2019-04-21 18:53:53'),
(27, 27, 'images/products/alpha_men_multivitamin_tablets.png\r\n', '2019-04-21 18:54:04'),
(28, 28, 'images/products/hemp_oil_capsules.png\r\n', '2019-04-21 18:54:20'),
(29, 29, 'images/products/healthshield_antoxidant_formula.png\r\n', '2019-04-21 18:54:27'),
(30, 30, 'images/products/super_magnesium_with_vitamin_b_complex.png\r\n', '2019-04-21 18:54:34'),
(31, 31, 'images/products/probiotic_max_tablets.png\r\n', '2019-04-21 18:54:41'),
(32, 32, 'images/products/chewable_vitamin_c_tablets.png\r\n', '2019-04-21 18:54:49'),
(33, 33, 'images/products/slimfast_shake_powder.png\r\n', '2019-04-21 18:54:56'),
(34, 34, 'images/products/battery_3_powder.png\r\n', '2019-04-21 18:55:04'),
(35, 35, 'images/products/intra_bcaa+.png\r\n', '2019-04-21 18:55:11'),
(36, 36, 'images/products/waxy_vol_powder.png\r\n', '2019-04-21 18:55:23'),
(37, 37, 'images/products/vmx2_powder.png\r\n', '2019-04-21 18:55:30'),
(38, 38, 'images/products/amino_drive.png\r\n', '2019-04-21 18:55:37'),
(39, 39, 'images/products/vmx2_shot.png\r\n', '2019-04-21 18:55:44'),
(40, 40, 'images/products/amino_support_tablets.png\r\n', '2019-04-21 18:55:55'),
(41, 41, 'images/products/pre-workout_burn.png\r\n', '2019-04-21 18:56:02'),
(42, 42, 'images/products/pre-workout_perform.png\r\n', '2019-04-21 18:56:13'),
(43, 43, 'images/products/pre-workout_pump.png\r\n', '2019-04-21 18:56:20'),
(44, 44, 'images/products/l-leucine_capsules.png\r\n', '2019-04-21 18:56:27'),
(45, 45, 'images/products/reinforce_capsules.png\r\n', '2019-04-21 18:56:34'),
(46, 46, 'images/products/cla_softgels.png\r\n', '2019-04-21 18:56:41'),
(47, 47, 'images/products/protein_flapjack.png\r\n', '2019-04-21 18:56:48'),
(48, 48, 'images/products/yoga_mat.png\r\n', '2019-04-21 18:56:55'),
(49, 49, 'images/products/gymgear_slam_ball.png\r\n', '2019-04-21 18:57:02'),
(50, 50, 'images/products/speed_ladder.png\r\n', '2019-04-21 18:57:09');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` bigint(11) NOT NULL,
  `type` int(1) NOT NULL,
  `bank_card_number` bigint(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `email`, `password`, `created_at`, `first_name`, `last_name`, `address`, `phone`, `type`, `bank_card_number`) VALUES
(8, 'admin', '$2y$10$zYXArhg86FYSbj73oZdcA.rnPcIDGJq1wc/GXvc9wQjWhv9P1bJIi', '2019-04-05 02:12:42', '', '', '', 0, 0, 0),
(9, 'adminA', '$2y$10$OZhbQPJjQy6IzSZyMtfXNuqOxHz67CbhubCrU51bzghUF0mxnieH6', '2019-04-05 02:18:33', '', '', '', 0, 0, 0),
(10, 'abc', '$2y$10$.JKRWVew6ZDTF6jl0mrlouTax5X7GUg18XyREmem8zILmmRY7BhvO', '2019-04-05 02:24:45', '', '', '', 0, 0, 0),
(11, 'testbeta', '$2y$10$HxovhVuEZCf93AlyiZyWsePkPUgnzgLgAkZgAWS3XNVHJuDghp1Dy', '2019-04-05 03:03:57', '', '', '', 0, 0, 0),
(12, 'andrei.rusu.net@gmail.com', '$2y$10$t89WMNuIoPB1y8JnfFIeAO/tG8/n0aC5tNvTDsT3tCyO3NlA8Sc6e', '2019-04-05 03:33:53', '', '', '', 0, 0, 0),
(13, 'admintest', '$2y$10$qMceqNIdWFN2c4m8y7ISfueLDQDXksvZg1WtCBc6RTUhAHhjG2hnq', '2019-04-08 09:23:19', '', '', '', 0, 0, 0),
(14, 'testemail@gmail.com', '$2y$10$eYFmEOoa/oHH/oKU20U5oumUF9e1QWP.yL1.jtp/Fek1z80vG9sMa', '2019-04-10 14:24:33', '', '', '', 0, 0, 0),
(15, 'test@test.com', '$2y$10$ASUmb5EcFtjhjNXPs6CN/OV52nt1WO6blXFeKGGwa5KCZVjFrB5hG', '2019-04-21 19:26:07', '', '', '', 0, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bank`
--
ALTER TABLE `bank`
  ADD PRIMARY KEY (`card_number`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`,`category_id`),
  ADD KEY `fk_product_category1_idx` (`category_id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `order_details`
--
ALTER TABLE `order_details`
  ADD CONSTRAINT `fk_order_details_order1` FOREIGN KEY (`order_id`) REFERENCES `order` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_product_category1` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
